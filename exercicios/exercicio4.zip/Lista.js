import React, { useState } from "react";
import { ScrollView, Text } from "react-native";
import styled from "styled-components/native";

const Item = styled.TouchableOpacity`
  padding: 15px;
  margin: 5px;
  border-radius: 8px;
  background-color: ${(props) => (props.selected ? "#6200ee" : "#e0e0e0")};
  align-items: center;
`;

const ItemText = styled.Text`
  color: ${(props) => (props.selected ? "#fff" : "#000")};
  font-size: 16px;
  font-weight: bold;
`;

const Lista = () => {
  const [selectedItem, setSelectedItem] = useState(null);
  const items = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"];

  return (
    <ScrollView style={{ width: "100%", marginTop: 20 }}>
      {items.map((item, index) => (
        <Item
          key={index}
          selected={selectedItem === index}
          onPress={() => setSelectedItem(index)}
        >
          <ItemText selected={selectedItem === index}>{item}</ItemText>
        </Item>
      ))}
    </ScrollView>
  );
};

export default Lista;
