import React from "react";
import { View } from "react-native";
import Lista from "./components/Lista";

const App = () => {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Lista />
    </View>
  );
};

export default App;
