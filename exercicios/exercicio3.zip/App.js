import React from "react";
import { View } from "react-native";
import Header from "./components/Header";

const App = () => {
  return (
    <View style={{ flex: 1 }}>
      <Header title="Meu Header" />
    </View>
  );
};

export default App;
