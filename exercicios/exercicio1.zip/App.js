import React from 'react';
import { View, Alert, StyleSheet } from 'react-native';
import Button from './components/Button';

const App = () => {
  return (
    <View style={styles.container}>
      <Button
        text="Botão Normal"
        onPress={() => Alert.alert('Botão normal pressionado!')}
      />


      <Button
        text="Botão Laranja"
        color="orange"
        onPress={() => Alert.alert('Botão laranja pressionado!')}
      />


      <Button
        text="Desativado"
        color="gray"
        disabled={true}
        onPress={() => { }}
      />

      <Button
        text="Botão Redondo"
        color="blue"
        rounded={true}
        onPress={() => Alert.alert('Botão redondo pressionado!')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default App;