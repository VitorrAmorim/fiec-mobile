import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

const Button = ({ text, color, disabled, rounded, onPress }) => {
  return (
    <TouchableOpacity
      style={[
        styles.button,
        { 
          backgroundColor: color || 'green',
          opacity: disabled ? 0.5 : 1,
          borderRadius: rounded ? 50 : 5,
        }
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={styles.text}>{text}</Text>
    </TouchableOpacity>
  );
};

// Estilos básicos
const styles = StyleSheet.create({
  button: {
    padding: 15,
    borderRadius: 5,
    margin: 10,
    alignItems: 'center',
  },
  text: {
    color: 'white',
    fontSize: 16,
  },
});



export default Button;